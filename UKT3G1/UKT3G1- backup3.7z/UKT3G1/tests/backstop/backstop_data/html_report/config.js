report({
  "testSuite": "BackstopJS",
  "tests": [
    {
      "pair": {
        "reference": "../bitmaps_reference/project_devel_config_SexyProjectHome_0_document_0_phone.png",
        "test": "../bitmaps_test/20190311-224243/project_devel_config_SexyProjectHome_0_document_0_phone.png",
        "selector": "document",
        "fileName": "project_devel_config_SexyProjectHome_0_document_0_phone.png",
        "label": "SexyProjectHome",
        "requireSameDimensions": true,
        "misMatchThreshold": 0.1,
        "url": "http://localhost:5555",
        "referenceUrl": "",
        "expect": 0,
        "viewportLabel": "phone",
        "diff": {
          "isSameDimensions": true,
          "dimensionDifference": {
            "width": 0,
            "height": 0
          },
          "misMatchPercentage": "0.83",
          "analysisTime": 106
        },
        "diffImage": "../bitmaps_test/20190311-224243/failed_diff_project_devel_config_SexyProjectHome_0_document_0_phone.png"
      },
      "status": "fail"
    },
    {
      "pair": {
        "reference": "../bitmaps_reference/project_devel_config_SexyProjectHome_0_document_1_tablet.png",
        "test": "../bitmaps_test/20190311-224243/project_devel_config_SexyProjectHome_0_document_1_tablet.png",
        "selector": "document",
        "fileName": "project_devel_config_SexyProjectHome_0_document_1_tablet.png",
        "label": "SexyProjectHome",
        "requireSameDimensions": true,
        "misMatchThreshold": 0.1,
        "url": "http://localhost:5555",
        "referenceUrl": "",
        "expect": 0,
        "viewportLabel": "tablet",
        "diff": {
          "isSameDimensions": true,
          "dimensionDifference": {
            "width": 0,
            "height": 0
          },
          "misMatchPercentage": "0.76",
          "analysisTime": 169
        },
        "diffImage": "../bitmaps_test/20190311-224243/failed_diff_project_devel_config_SexyProjectHome_0_document_1_tablet.png"
      },
      "status": "fail"
    }
  ],
  "id": "project_devel_config"
});