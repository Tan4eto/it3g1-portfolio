# from sqlalchemy import create_engine
# #from sqlalchemy.orm import sessionmaker
# from UKT3G1.Models import Base, User, UserTests
# from sqlalchemy import orm
#
# engine = create_engine('sqlite:///testdb.db', echo=True)
#
# Base.metadata.create_all(bind=engine)
#
# # Set up the session
# sm = orm.sessionmaker(bind=engine, autoflush=True, autocommit=True,
#     expire_on_commit=True)
# session = orm.scoped_session(sm)
#
# #DBSession = sessionmaker(bind=engine)
# #session = DBSession()
