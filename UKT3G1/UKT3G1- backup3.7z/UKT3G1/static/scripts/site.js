function show_logged_user() {

    $('#elm').hover(
        function(){ $(this).removeClass('hover') }
    )
    $('#elm').hover(
        function(){ $(this).removeClass('hover') }
    )
 }
